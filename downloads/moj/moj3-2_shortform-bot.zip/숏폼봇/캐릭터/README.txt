캐릭터 시트를 넣는 곳입니다.
김법무.png, 박법무.jpg, 서법무.jpg, 최법무.jpg (없으면 menpd.com/moj-shortform-bot.html 에서 받기)
새로 만든 캐릭터도 봇이 여기에 저장합니다.
