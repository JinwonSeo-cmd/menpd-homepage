# 스타일 메뉴판 한 장 만들기 : python 공통/메뉴판만들기.py 2_포스터봇
# 샘플/스타일_NN_이름.png (00 제외)를 작은 썸네일 블록으로 모아 샘플/_메뉴판.png 로 저장
import sys,os,re,glob
from PIL import Image,ImageDraw,ImageFont,ImageOps
here=os.path.dirname(os.path.abspath(__file__));bot=sys.argv[1] if len(sys.argv)>1 else '.'
if not os.path.isabs(bot): bot=os.path.join(os.path.dirname(here),bot)
sd=os.path.join(bot,'샘플')
items={}
for f in sorted(glob.glob(os.path.join(sd,'스타일_*'))):
    b=os.path.basename(f)
    if os.path.isdir(f):
        m=re.match(r'스타일_(\d+)_(.+)$',b)
        imgs=sorted(g for g in glob.glob(os.path.join(f,'*')) if re.search(r'\.(png|jpe?g|webp)$',g,re.I))
        if m and imgs and int(m.group(1))>0: items.setdefault(int(m.group(1)),(int(m.group(1)),m.group(2),imgs[0]))
    else:
        m=re.match(r'스타일_(\d+)_(.+)\.(png|jpe?g|webp)$',b,re.I)
        if m and int(m.group(1))>0: items[int(m.group(1))]=(int(m.group(1)),m.group(2),f)
items=[items[k] for k in sorted(items)]
if not items: print('스타일 이미지 없음'); sys.exit(0)
F=lambda s,b=True:ImageFont.truetype(os.path.join(here,'폰트','Pretendard-Bold.ttf' if b else 'Pretendard-SemiBold.ttf'),s)
portrait='포스터' in os.path.basename(os.path.normpath(bot))
TW=200;TH=int(TW*4/3) if portrait else int(TW*5/4);G,LB=16,44
C=min(len(items),6)
R=(len(items)+C-1)//C;W=C*TW+(C+1)*G;H=70+R*(TH+LB+G)+G
cv=Image.new('RGB',(W,H),'#FFF8F0');d=ImageDraw.Draw(cv)
d.text((G,20),'스타일 메뉴판 · 번호로 골라 주세요',fill='#1F3A5F',font=F(28))
for k,(n,name,f) in enumerate(items):
    x=G+(k%C)*(TW+G);y=70+(k//C)*(TH+LB+G)
    im=ImageOps.fit(Image.open(f).convert('RGB'),(TW,TH),Image.LANCZOS,centering=(0.5,0.4))
    d.rounded_rectangle((x-2,y-2,x+TW+2,y+TH+LB+2),12,fill='#FFFFFF')
    cv.paste(im,(x,y));d.ellipse((x+8,y+8,x+48,y+48),fill='#2D6B7A')
    t=str(n);w=d.textlength(t,font=F(22));d.text((x+28-w/2,y+14),t,fill='#fff',font=F(22))
    nm=name.replace('_',' ');d.text((x+10,y+TH+9),nm[:11],fill='#1F3A5F',font=F(21,False))
out=os.path.join(sd,'_메뉴판.png');cv.save(out);cv.save(os.path.join(sd,'스타일_00_전체비교.png'));print(out,len(items),'개')
