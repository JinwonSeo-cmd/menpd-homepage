# Integrated Biosciences — Style Reference
> bioluminescent laboratory at midnight

**Theme:** mixed (dark hero/content bands + light editorial band)

A darkroom-laboratory visual language: a near-black canvas with cool green undertones, restrained white typography, and a single bioluminescent lime accent (#cef79e) that activates only on micro-elements — arrow buttons, tag dots, active nav pills, progress indicators. The type system runs on a single weight of Aspekta; hierarchy is sculpted purely by size and aggressive negative tracking, making 111px and 158px display lines architectural. Roboto Mono is reserved for technical labels, nav, and metadata — the instrumentation-bench voice. Surfaces are flat — no shadows, no gradients — with thin hairlines (#c9cbbe on light, #4d5757 on dark) doing all delineation. Light sections flip to warm off-white (#f7f7f5) with white cards; the green accent persists as a constant biological signal.

## Tokens — Colors

| Name | Value | Role |
|------|-------|------|
| Bioluminescent Lime | `#cef79e` | The signal lamp: 40×40 arrow buttons, 6px tag dots, active nav pills. Never large surfaces, never behind body text |
| Abyssal Ink | `#222f30` | Primary text, dark canvas, nav — near-black with green undertone |
| Bone White | `#f7f7f5` | Light-section canvas |
| Paper | `#ffffff` | Cards on light sections, text on dark |
| Graphite | `#4d5757` | Secondary text, metadata, dark-mode hairlines, ghost outlines |
| Lichen | `#c9cbbe` | Light-mode hairlines, placeholder metadata |
| Tissue | `#e7e8e1` | Alternate warm card surface (light sections only) |
| Frost | `#eeeeee` | Neutral light card alternate |
| Void | `#000000` | Footer only |

## Tokens — Typography

- **Aspekta** (substitute: Inter Tight 400 or Söhne Buch) — sole display and body face, **weight 400 only**. No bold, no italic. Tracking scales with size: -0.03em at 158px, -0.02em at 89–111px, -0.006em at 36–42px, -0.001em at 16–19px.
- **Roboto Mono** (substitute: JetBrains Mono / IBM Plex Mono) — nav, section counters (01/02), tags, dates, button text only; 13–15px. Never for headlines or long copy.

| Role | Size | Line Height | Tracking |
|------|------|-------------|----------|
| caption (mono) | 13px | 1.23 | -0.26px |
| body | 18px | 1.3 | -0.018px |
| body-lg | 22px | 1.3 | -0.13px |
| subheading | 24px | 1.2 | -0.14px |
| heading-sm | 36px | 1.2 | -0.22px |
| heading-lg | 58px | 1.1 | -0.7px |
| display | 75px | 1.1 | -1.5px |
| display-lg | 89px | 1.1 | -1.78px |
| display-xl | 111px | 1.0 | -2.22px |
| hero | 158px | 1.0 | -4.74px |

## Spacing & Shapes

Base unit 4px, comfortable. Scale: 4, 8, 12, 16, 20, 24, 40, 44, 48, 52, 60, 88, 100, 160px.
Radius: buttons 8px · nav 12px · cards 16–20px · large cards 40px · tags/counters 9999px.
Layout: max-width 1200px · section gap 80–120px · card padding 40px · element gap 8–20px.

## Components

- **Hero display headline:** Aspekta 400, 111–158px, line-height 1.0, -0.03em, white on #222f30, left-aligned, period-terminated; ≥400px negative space between headline and copy.
- **Section sub-headline:** 36–42px/400, Graphite on dark or Ink on light — a quiet reflective counterpoint.
- **Pill nav button:** 1px outline (#c9cbbe dark / #4d5757 light), 12px radius, mono 13–14px; active → lime fill, Ink text.
- **Filled action button:** #222f30 on light / #ffffff on dark, 8px radius, mono 13–14px uppercase, padding 8px 12–16px. Restrained size.
- **Arrow CTA:** 40×40 square, 8px radius, lime fill, Ink arrow — the only place lime fills a shape.
- **Outlined ghost button:** 1px #4d5757, 8px radius, mono 14px.
- **Section counter:** small pill "01 / 02", 1px #4d5757 border, mono 13px.
- **News article card:** white on Bone, 20–40px radius, 40px padding, 2-column (dark scientific image left with 12–16px radius, title/meta/excerpt/"READ ARTICLE" right).
- **Publication tag:** 6px lime dot + mono uppercase label.
- **Hairline divider:** 1px horizontal only — never vertical, double, or dashed.
- **Footer:** pure black, white text, mono links.

## Do's and Don'ts

### Do
- Aspekta 400 for all display and body; hierarchy by size and tracking only.
- Lime at micro-scale only (40×40 arrows, 6px dots).
- Scale tracking proportionally with size.
- 1px hairlines for dividers/borders; no shadows.
- Mono only for nav, counters, tags, dates, button text.
- 80–120px section gaps — the system breathes.
- Dark button on light canvas; white button on dark canvas.

### Don't
- No second weight or second sans for headings.
- No lime as background for body text, large surfaces, gradients, hero overlays — and never as a primary button background.
- No box-shadows or elevation effects.
- No pure #000 in content sections (footer only).
- No warm neutrals (#e7e8e1, #c9cbbe) on dark sections.
- No images outside rounded containers (min 12px) or without the dark scientific treatment; no lifestyle photography.
- No second accent color.

## Surfaces & Elevation

| Level | Name | Value |
|-------|------|-------|
| 0 | Canvas — Light | `#f7f7f5` |
| 1 | Canvas — Dark | `#222f30` |
| 2 | Card — Light | `#ffffff` |
| 3 | Card — Warm alt | `#e7e8e1` |
| 4 | Accent fill | `#cef79e` |
| 5 | Footer | `#000000` |

Deliberately flat — a printed scientific poster. Depth only from color contrast and hairlines.

## Imagery

Scientific microscopy and 3D molecular renders (cell clusters, protein structures, neural networks) in a single dark-green-to-black palette; always contained in rounded rectangles; highlights echo the lime accent. No photography, no text overlays.

## Layout

1200px centered column. Dark full-bleed bands (hero, "What we do", platform) → light full-bleed band (newsroom); no dividers between same-mode sections. Asymmetric hero: headline in the left two-thirds, lots of right/bottom negative space. 2-column image/text editorial cards. Minimal single-bar nav with pill active indicator; no sticky header or sidebar.

## Accent Discipline

Lime appears only on 40×40 arrow buttons, 6px tag dots, active nav pills, and progress indicators — on = active, forward, or biological. Because everything else is monochrome, the eye locks onto it.

## Agent Prompt Guide

- text #222f30 (dark) / #ffffff (on dark) · background #f7f7f5 / #222f30 · border #c9cbbe / #4d5757 · accent #cef79e · no filled CTA color.
- Hero: full-bleed #222f30, 158px Aspekta 400 white, line-height 1.0, tracking -4.74px, left-aligned.
- Section counter: dark band, "01 / 02" pill with 1px #4d5757 border, mono 13px, 42px Graphite headline, max-width 600px.
- Ghost nav: transparent, 1px #c9cbbe, 12px radius, mono 13px; active → #cef79e fill + #222f30 text.

## Similar Brands
Arc Institute · Chai Discovery · EvolutionaryScale · Linear

## Quick Start (CSS)

```css
:root {
  --color-lime: #cef79e; --color-abyssal-ink: #222f30; --color-bone: #f7f7f5; --color-paper: #ffffff;
  --color-graphite: #4d5757; --color-lichen: #c9cbbe; --color-tissue: #e7e8e1; --color-void: #000000;
  --font-aspekta: 'Aspekta', 'Inter Tight', system-ui, sans-serif;
  --font-mono: 'Roboto Mono', 'JetBrains Mono', monospace;
  --weight: 400; --text-hero: 158px; --text-display: 111px; --text-h1: 58px; --text-h2: 36px; --text-body: 18px;
  --radius-button: 8px; --radius-nav: 12px; --radius-card: 20px; --radius-pill: 9999px;
  --card-padding: 40px; --section-gap: 100px; --page-max-width: 1200px;
}
```
