# Raycast — Style Reference
> Midnight command center, coral neon

**Theme:** dark

Raycast reads as a dark power-tool cockpit: an almost-black canvas (#040506) with barely-visible elevation steps, a single warm coral accent (#ff6363) carrying brand identity, and quiet white/gray Inter typography. Components are defined by hairline borders, inset highlight strokes, and a "keyboard key" inner-shadow treatment that makes cards feel pressed and tactile. The page is 98% achromatic; coral appears only in logo, hero artwork, badges, and the occasional warm-tinted surface. Most interactive surfaces are neutral light-gray buttons on dark, not chromatic CTAs. The hero breaks the system with large red/blue gradient geometry, then the page returns to austere dark — contrast through atmosphere, not decoration.

## Tokens — Colors

| Name | Value | Role |
|------|-------|------|
| Void Black | `#040506` | Page canvas — the only page background |
| Ink | `#07080a` | Card surfaces, elevated panels |
| Obsidian | `#111214` | Input wells, pressed/recessed states |
| Graphite | `#1b1c1e` | Badge fill, quiet UI feedback |
| Smoke | `#6a6b6c` | Muted labels, secondary body |
| Ash | `#9c9c9d` | Secondary text on dark, nav links |
| Mist | `#e6e6e6` | Light neutral button fill |
| Iron | `#454647` | Button text on Mist fill |
| Slate | `#2f3031` | Dark button borders |
| Pure White | `#ffffff` | Headings, high-emphasis text |
| Coral Pulse | `#ff6363` | Brand accent — logo, key highlight, the single warm punctuation |
| Ember Hush | `#452324` | Warm-tinted card backgrounds |
| Electric Sky | `#63a1ff` | Hero artwork only |
| Cobalt Edge | `#143ca3` | Hero artwork only |
| Deep Space | `#02193b` | Hero artwork only |
| Info Blue | `#56c2ff` | Supporting accent wash |
| Success Green | `#59d499` | Supporting accent wash |
| Border | `#363739` | Hairline borders |

## Tokens — Typography

- **Inter** — body 16/400; nav & labels 13–14/500; subheadings 18–22/400; section headings 32–56 (400–600); display 64/600. Hero at 56px/**400** (regular weight at large size is a signature). Slight positive tracking (+0.22px at 56px). Eyebrow: 11px uppercase, +0.8px.
- **Geist Mono** (substitute JetBrains Mono) — version strings, technical micro-labels, 10–12px.
- **SF Pro Text** — icon glyphs and numeric stat callouts only (24–32px/500).

| Role | Size | Line Height | Tracking |
|------|------|-------------|----------|
| eyebrow | 11px | 0.91 | 0.8px |
| body | 16px | 1.15 | 0 |
| body-lg | 18px | 1.15 | 0 |
| subheading | 20px | 1.2 | 0.2px |
| heading-sm | 24px | 1.15 | 0 |
| heading | 32px | 1.15 | 0 |
| heading-lg | 56px | 1.17 | 0.22px |
| display | 64px | 1.1 | 0 |

## Spacing & Shapes

Base unit 8px. Scale: 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 120px.
Radius: cards 16px · large cards 20px · buttons/inputs 8px · badges 6px · pills 9999px · icon containers 99999px.
Layout: max-width 1200px · section gap 80–120px · card padding 24px · element gap 8–16px.

Key shadow stack (the "keyboard key" look): `rgba(255,255,255,0.05) 0 1px 0 inset, rgba(255,255,255,0.25) 0 0 0 1px, rgba(0,0,0,0.2) 0 -1px 0 inset`.

## Components

- **Glass nav bar:** floating pill, backdrop-blur 48px, 1px #363739 border, 8px radius, transparent dark fill; logo left, links in Ash 13–14px, Mist button right.
- **Neutral filled button:** Mist fill, Iron text 13–14/500, 8px radius, padding 8px 12px. The only filled action surface.
- **Ghost nav link:** Ash text, hover → white.
- **Feature card (key shadow):** 16px radius, 24px padding, transparent fill showing canvas, key shadow stack — pressed keycap, not floating.
- **Edge-highlight card:** 1px #363739 border + inset highlight, for hover/featured.
- **Inset input:** 8px radius, rgba(255,255,255,0.05) fill, white text, Ash placeholder.
- **Badge tag:** Graphite fill, white text, 6px radius.
- **Circular icon container:** 99999px radius, 20px padding, dark fill, 24–32px glyph.
- **Hero gradient banner:** red/coral diagonal bars (40px+ blur) over a blue radial wash — the one place the system breaks its rules.
- **Footer meta strip:** Geist Mono 12px Ash, pipe-separated.

## Do's and Don'ts

### Do
- #040506 as the only page background.
- Reserve #ff6363 for logo, hero artwork, badges, warm-tinted surfaces.
- Use the key shadow stack on elevated cards.
- Hero headlines 56px/400 Inter, +0.22px tracking.
- Mist buttons with Iron text for primary actions — no chromatic CTA.
- 8px radius for buttons/inputs/badges, 16–20px cards.
- Snap all spacing to the 8px grid.

### Don't
- Don't use chromatic action buttons.
- Don't add outer drop shadows to cards.
- Don't use negative tracking on large display text.
- Don't introduce light sections or alternating light/dark bands.
- Don't use coral for body text, links, or generic icons.
- Don't mix multiple accent colors on one surface.
- Don't use SF Pro Text for body copy.

## Surfaces

| Level | Name | Value |
|-------|------|-------|
| 0 | Canvas | `#040506` |
| 1 | Card | `#07080a` |
| 2 | Recessed | `#111214` |
| 3 | Badge | `#1b1c1e` |
| 4 | Accent Tint | `#452324` |

## Imagery

Cinematic abstract red/blue geometry in the hero (motion-graphics title feel); below it, austere in-context product screenshots (dark command bar, result list, extension icons). No photography or stock. Icons: SF Pro glyphs 16–24px in Mist.

## Layout

Max-width ~1200px centered; hero full-bleed, full-viewport with centered headline. Sections: dark-on-dark bands with hairline dividers, 3-column compact tiles or 2-column feature blocks, one strong typographic statement per section, spacious density.

## Agent Prompt Guide

- text #ffffff / #9c9c9d / #6a6b6c · background #040506 · card #07080a · border #363739 · brand accent #ff6363 · primary action #e6e6e6.
- Hero: full-bleed #040506, centered 56px Inter 400 white headline, 16px #9c9c9d subhead, behind it coral bars + blue radial wash, below two Mist buttons and a Geist Mono 12px meta line.
- Feature card: 16px radius, transparent on #07080a, key shadow stack, circular icon container, 20px/500 white title, 16px/400 #9c9c9d body.

## Similar Brands
Linear · Vercel · Arc Browser · Cron · Tana

## Quick Start (CSS)

```css
:root {
  --color-void-black: #040506; --color-ink: #07080a; --color-obsidian: #111214; --color-graphite: #1b1c1e;
  --color-smoke: #6a6b6c; --color-ash: #9c9c9d; --color-mist: #e6e6e6; --color-iron: #454647;
  --color-white: #ffffff; --color-coral-pulse: #ff6363; --color-ember-hush: #452324; --color-border: #363739;
  --font-inter: 'Inter', system-ui, sans-serif; --font-mono: 'Geist Mono', 'JetBrains Mono', monospace;
  --radius-card: 16px; --radius-button: 8px; --radius-badge: 6px; --radius-pill: 9999px;
  --shadow-key: rgba(255,255,255,0.05) 0 1px 0 0 inset, rgba(255,255,255,0.25) 0 0 0 1px, rgba(0,0,0,0.2) 0 -1px 0 0 inset;
  --spacing-unit: 8px; --page-max-width: 1200px;
}
```
