# Notion — Style Reference
> warm paper notebook under afternoon sun

**Theme:** light

Notion reads like a well-loved paper notebook under afternoon light: a warm off-white canvas (#f6f5f4) that feels tactile rather than clinical, generous sans typography with editorial weight, and color used as sparse punctuation — peachy pills highlight verbs, a single blue anchors the primary action, and a rotating cast of accent hues (coral, amber, sky, midnight) paints feature card backgrounds like sticky notes. Cards sit on the canvas with 1px hairline borders and 12px corners — no shadows, no chrome. Motion is playful and springy: 200ms ease transitions, bouncy character-mark animations.

## Tokens — Colors

| Name | Value | Token | Role |
|------|-------|-------|------|
| Notion Blue | `#0075de` | `--color-notion-blue` | Primary CTA fill, the single chromatic commitment in a near-monochrome system |
| Paper Warmth | `#f6f5f4` | `--color-paper-warmth` | Page canvas, hero and section backgrounds |
| Pure White | `#ffffff` | `--color-pure-white` | Card surfaces, elevated panels, text on dark cards |
| Ink Black | `#000000` | `--color-ink-black` | Primary text/headings, used at alpha 100/95/90/60/40/20% to build hierarchy |
| Charcoal | `#111111` | `--color-charcoal` | Softer dark text |
| Stone | `#757575` | `--color-stone` | Secondary/muted text |
| Graphite | `#615d59` | `--color-graphite` | Warm-cast body text |
| Slate | `#696969` | `--color-slate` | Card body text |
| Sky Tint | `#e6f3fe` | `--color-sky-tint` | Ghost CTA background, soft blue wash |
| Marigold | `#ffb110` | `--color-marigold` | Hero pill highlights, accent card background |
| Coral | `#f64932` | `--color-coral` | Decorative card backgrounds, pill alternates |
| Saffron | `#e89d01` | `--color-saffron` | Warm yellow accent panels |
| Vermillion | `#e32d14` | `--color-vermillion` | Deep coral panels |
| Mocha | `#b18164` | `--color-mocha` | Earthy brown accent panels |
| Signal Blue | `#097fe8` | `--color-signal-blue` | Decorative blue accent |
| Sky Wash | `#62aef0` | `--color-sky-wash` | Light blue decorative backgrounds |
| Midnight Ink | `#02093a` | `--color-midnight-ink` | Dark navy feature cards ("dark island") |
| Peach (pill) | `#f6d5b8` | — | Hero highlight pill behind a verb |

## Tokens — Typography

- **NotionInter** (substitute: Inter) — primary sans. 400 body, 500 nav/UI, 600–700 display. Aggressive negative tracking at large sizes (-4.6px at 96px, -2px at 72px).
- **Lyon Text** (substitute: Source Serif Pro) — editorial serif, 400, 18px/32px, used sparingly for section intros and pull-quote moments only. Never for UI labels.

| Role | Size | Line Height | Letter Spacing |
|------|------|-------------|----------------|
| caption | 12px | 1.33 | 0.12px |
| body-sm | 14px | 1.43 | — |
| body | 16px | 1.5 | — |
| subheading | 20px | 1 | — |
| heading-sm | 22px | 1.27 | -0.242px |
| heading | 40px | 1.5 | — |
| heading-lg | 48px | 1.5 | — |
| display-sm | 54px | 1.04 | -1.89px |
| display | 72px | 1.21 | -2.016px |
| display-lg | 96px | 1.04 | -4.608px |

## Spacing & Shapes

Base unit 4px, comfortable. Scale: 4, 8, 12, 16, 20, 24, 28, 32, 36, 64, 80px.
Radius: cards 12px · buttons 8px · small 4px · pills 9999px.
Layout: max-width 1440px · section gap 80px · card padding 24px · element gap 8px.

## Components

- **Primary CTA:** bg #0075de, text white 14px/500, radius 8px, padding 6px 15px. The only chromatic filled button.
- **Ghost CTA:** bg #e6f3fe, text #0075de, radius 8px. Lower-commitment alternative.
- **Ghost text button:** transparent, text black 95%.
- **Outlined text button:** 1px border, radius 4px, padding 5px 10px.
- **Muted nav link:** black 54% alpha, darkens on hover, no underline.
- **Pill tag:** colored fill, radius 9999px, padding 4px 12px.
- **White feature card:** #fff, radius 12px, padding 24px, 1px border rgba(0,0,0,0.08), no shadow.
- **Accent feature card:** fill with one accent hue (#ffb110, #f64932, #62aef0, #e6f3fe), radius 12px, no border.
- **Dark feature card:** #02093a, white text, radius 12px; used sparingly.
- **Hero highlight pill:** accent fill behind a single verb, text black, radius 9999px, padding 8px 24px. The signature device.
- **Avatar character mark:** 40–48px circle, 2px colored border, flat illustration, white fill.
- **Section header:** NotionInter 500–700, 48–54px, tracking -1.9 to -2px, optionally followed by an 18px Lyon Text subhead.
- **Logo wall:** greyscale (black 60% alpha) logos, no borders.

## Do's and Don'ts

### Do
- #f6f5f4 canvas, #ffffff cards — never invert this hierarchy.
- Reserve #0075de for the single primary action per screen; secondary uses ghost/text.
- Negative letter-spacing on all display sizes; body stays normal.
- Separate cards with 1px rgba(0,0,0,0.08) borders instead of shadows.
- 12px radius cards, 8px buttons, 9999px only for pills.
- Vary feature blocks by painting accent-hue backgrounds, not by adding borders/shadows.
- 200ms ease transitions; spring/bounce only for character marks and hero.

### Don't
- Don't use pure white as the page background.
- Don't add shadows to content cards (only nav and product mockup).
- Don't use multiple chromatic filled buttons in one view.
- Don't use #000 at 100% for all text — build hierarchy via alpha.
- Don't use Lyon Text for UI labels or navigation.
- Don't exceed 12px radius on rectangles.
- Don't use gradients — flat fills only.

## Surfaces

| Level | Name | Value | Purpose |
|-------|------|-------|---------|
| 0 | Page Canvas | `#f6f5f4` | Warm off-white base |
| 1 | Card Surface | `#ffffff` | Cards that sit "on top" |
| 2 | Accent Card | `#ffb110` etc. | Single-hue feature blocks |
| 3 | Dark Card | `#02093a` | Navy panels with white text |

Elevation: nav `0 3px 9px rgba(0,0,0,0.03)`; product mockup `0 4px 12px rgba(0,0,0,0.1)`.

## Imagery

Illustration-first, photography-free: flat round character faces in colored circles, hand-drawn squiggles, sparkles, arrows, flower shapes, plus real product UI mockups (kanban, docs). No lifestyle photos, stock imagery, or 3D renders.

## Layout

Centered, max ~1440px. Hero stack: character-mark row → two-line headline with embedded colored pill → subhead → two-button CTA row → large product mockup. Sections alternate white-card grids and full-bleed colored panels; 2-column text+panel blocks alternate left/right; 2×2 card grids. Section gaps ~80px, calm vertical rhythm. Fixed 64px top nav.

## Agent Prompt Guide

- text #000000 (alpha hierarchy) · background #f6f5f4 · card #ffffff · border rgba(0,0,0,0.08) · primary action #0075de · accents #ffb110, #f64932, #62aef0, #02093a.
- Hero example: centered on #f6f5f4, 72px NotionInter 500, line-height 1.21, tracking -2.016px; wrap one word in a #f6d5b8 pill; 18px Lyon Text subhead in #615d59.
- Card example: #fff, radius 12px, padding 24px, 1px rgba(0,0,0,0.08); title 22px/700, body 16px #615d59.

## Similar Brands
Linear (monochrome + single accent, hairline cards) · Stripe (serif+sans pairing, tight display type) · Figma (playful marks, rotating accents) · Craft Docs (paper-warm document feel).

## Quick Start (CSS)

```css
:root {
  --color-notion-blue: #0075de; --color-paper-warmth: #f6f5f4; --color-pure-white: #ffffff;
  --color-ink-black: #000000; --color-graphite: #615d59; --color-sky-tint: #e6f3fe;
  --color-marigold: #ffb110; --color-coral: #f64932; --color-sky-wash: #62aef0; --color-midnight-ink: #02093a;
  --font-notioninter: 'NotionInter', 'Inter', system-ui, sans-serif;
  --font-lyon-text: 'Lyon Text', 'Source Serif Pro', serif;
  --radius-card: 12px; --radius-button: 8px; --radius-pill: 9999px;
  --page-max-width: 1440px; --section-gap: 80px;
}
```
