# Mercury — Style Reference
> Alpine banking at blue hour

**Theme:** dark

An alpine banking aesthetic: a near-black indigo canvas (#171721) sets an observatory-like atmosphere where content surfaces float as subtly lighter graphite cards. Overwhelmingly monochromatic — ivory text on onyx — with a single vivid cobalt (#5266eb) as the only chromatic punctuation, reserved for the primary action. Typography carries the expression: a display face at intermediate weight 480 (neither bold nor light) with body at 400 — confident, never loud. Components are flat and borderless; structure comes from the 12px-radius graphite card lift and pill-shaped controls, not shadows. A full-bleed misty-mountain photographic hero establishes aspiration; every surface after it keeps that hushed, premium darkness.

## Tokens — Colors

| Name | Value | Role |
|------|-------|------|
| Onyx Canvas | `#171721` | Page background, section canvases, footer |
| Graphite Card | `#1e1e2a` | Elevated card/section surface — one step above canvas |
| Obsidian Button | `#272735` | Secondary button fills, subtle interactive surfaces |
| Slate Border | `#70707d` | Medium dividers and structural borders |
| Mist Border | `#e2e3ed` | Light hairlines, ghost-button outlines, input edges |
| Ash Text | `#c3c3cc` | Muted body copy, helper text, secondary labels |
| Ivory Text | `#ededf3` | Primary text, icons, nav, ghost-button strokes — dominant foreground |
| Cobalt | `#5266eb` | Filled primary button, selected states — the sole chromatic action |
| Pure White | `#ffffff` | Text on cobalt buttons; hero headline |

## Tokens — Typography

- **arcadia** (substitute: Inter) — body/UI. Weights 360/400/420/480. Body 400, emphasis 480. Never bold, never thin.
- **arcadiaDisplay** (substitute: Söhne Breit) — headlines. Weight **480** for all headings 28–65px; 530 only for the largest display moments. Tight line-height (1.1–1.2), positive tracking (0.01–0.02em) → wide-set, architectural feel.

| Role | Size | Line Height | Tracking |
|------|------|-------------|----------|
| caption | 12px | 1 | 0.12px |
| body-sm | 14px | 1 | 0.07px |
| body | 16px | 1.5 | — |
| body-lg | 18px | 1.35 | — |
| subheading | 21px | 1.35 | — |
| heading-sm | 28px | 1.2 | 0.42px |
| heading | 32px | 1.15 | 0.48px |
| heading-lg | 42px | 1.15 | 0.42px |
| display | 65px | 1.1 | — |

## Spacing & Shapes

Base unit 4px, spacious. Scale: 4, 8, 12, 16, 20, 24, 32, 40, 56, 72, 112, 128px.
Radius: cards 12px · buttons/inputs 32px · nav/tags 40px · structural default 4px.
Layout: max-width 1200px · section gap 72px · card padding 32px · element gap 12px.

## Components

- **Primary CTA (Cobalt):** #5266eb fill, white text 16px/400, pill (32px radius), no border/shadow. Gravitational center of the page.
- **Ghost outline button:** transparent, 1px #ededf3 border, Ivory text, 40px radius, 20px horizontal padding.
- **Nav pill link:** transparent, Ivory 16px, 40px radius; floats over hero, frosted (backdrop-blur 8–20px) on scroll.
- **Graphite card:** #1e1e2a, 12px radius, 32px padding, no shadow, no border.
- **Email capture:** left-half pill input (border-radius 32px 0 0 32px, Ivory 1px border) attached to a cobalt button (0 32px 32px 0).
- **Full-bleed hero:** 100vw × ~100vh photo with subtle dark overlay; centered 65px/480 headline + 18px/480 subtext, max-width ~640px.
- **Section container:** #171721, content max 1200px, 72px vertical padding; 2- or 3-column graphite card grids or text+image splits.
- **Disclaimer strip:** 12px/480, Ash text, minimal weight.

## Do's and Don'ts

### Do
- Cobalt exclusively for the single primary action per page.
- Cards: #1e1e2a, 12px radius, 32px padding; separate by value lift, not shadows.
- Headings at arcadiaDisplay 480 — never 600/700.
- 32–40px pill radius for all interactive controls.
- Body 16px/400, line-height 1.5.
- 72px vertical rhythm between major sections.
- Ivory #ededf3 for ghost-button border and text.

### Don't
- No multiple bright accent colors.
- No drop shadows.
- No bold weights (700+) in headings.
- No sharp corners (0–4px) on buttons/inputs/nav.
- No #ffffff body text — use Ivory.
- Don't cluster cobalt elements closer than 32px.
- No bright or mid-gray colored section bands — only #171721 or #1e1e2a.

## Surfaces & Elevation

| Level | Name | Value |
|-------|------|-------|
| 0 | Onyx Canvas | `#171721` |
| 1 | Graphite Card | `#1e1e2a` |
| 2 | Obsidian Button | `#272735` |

No shadows; elevation is value contrast alone.

## Imagery

Cinematic full-bleed photography in the hero — misty mountains, a solitary desk in nature; cool, slightly desaturated, with a dark overlay for legibility. Below: product UI screenshots and abstract atmospheric backgrounds. No illustrations. Icons are minimal line glyphs in Ivory.

## Layout

Dark throughout. Full-bleed hero with centered headline/subtext/email form → 1200px sections alternating text-left/image-right splits and 3-column card grids. Transparent top bar over hero, frosted on scroll. Generous breathing room; no sidebar.

## Agent Prompt Guide

- background #171721 · card #1e1e2a · primary text #ededf3 · muted #c3c3cc · border #e2e3ed · primary action #5266eb.
- Feature card: #1e1e2a, 12px radius, 32px padding, 28px/480 heading (+0.015em), 16px/400 body Ivory.
- CTA: #5266eb, white 16px/400, pill, 12px 24px padding.
- Hero: full-bleed photo + dark overlay, 65px/480 white centered headline, 18px Ivory subtext max-width 520px.

## Similar Brands
Wise · Ramp · Brex · Linear · Stripe

## Quick Start (CSS)

```css
:root {
  --color-onyx: #171721; --color-graphite-card: #1e1e2a; --color-obsidian: #272735;
  --color-slate-border: #70707d; --color-mist-border: #e2e3ed; --color-ash: #c3c3cc;
  --color-ivory: #ededf3; --color-cobalt: #5266eb; --color-white: #ffffff;
  --font-body: 'Inter', system-ui, sans-serif; --font-display: 'Söhne Breit', 'Inter', system-ui, sans-serif;
  --weight-display: 480; --weight-body: 400;
  --radius-card: 12px; --radius-button: 32px; --radius-nav: 40px;
  --card-padding: 32px; --section-gap: 72px; --page-max-width: 1200px;
}
```
