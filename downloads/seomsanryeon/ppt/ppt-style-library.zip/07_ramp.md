# Ramp — Style Reference
> Editorial finance desk, black-and-white pages with a single neon highlighter. A near-monochrome publication surface where one vivid chartreuse mark turns every interaction into a money signal.

**Theme:** light

A black-and-white editorial system punctuated by a single highlighter-yellow accent — a finance journal with a neon Sharpie. Warm off-white canvas, white cards, hairline gray borders, deep near-black text. The chartreuse (#e4f222) appears only where money moves — CTAs, live counters, active states. Typography is one neo-grotesque face (lausanne) at weight 400 only, large display sizes with tight leading (~1.0 at 64px) and positive tracking on small uppercase labels. Components are flat, hairline-bordered, shadow-free: cards rest on borders with 12–16px radii; buttons are 6px-radius rectangles. Rhythm 8/12/16/24px.

## Tokens — Colors

| Name | Value | Role |
|------|-------|------|
| Highlighter Yellow | `#e4f222` | Primary action fill, live counters, active states — the only chromatic accent |
| Ink | `#0c0a08` | Primary text, headings (warm near-black) |
| Obsidian | `#1a1919` | Dark panels, inverted sections, ticker band |
| Paper | `#ffffff` | Card surfaces, reversed text on dark |
| Bone | `#f4f2f0` | Page canvas, subtle washes, hover backgrounds |
| Ash | `#6d6c6b` | Secondary text, captions, muted labels |
| Hairline | `#e5e7eb` | Card borders, dividers — replace shadows |
| Smoke | `#d3d3d3` | Subtle borders, skeleton states |

## Tokens — Typography

- **lausanne** (substitute: Inter, IBM Plex Sans, or Söhne) — sole typeface everywhere. **Weight 400 only**; hierarchy through size and tracking. Enable `font-feature-settings: "ss01"`.
- Uppercase micro-labels: 10px, +0.018em tracking. Display: tight leading ≤ 1.05.

| Role | Size | Line Height |
|------|------|-------------|
| caption | 10px | 2.2 |
| body | 16px | 1.5 |
| subheading | 20px | 1.3 |
| heading-sm | 24px | 1.17 |
| heading | 28px | 1.14 |
| heading-lg | 40px | 1.05 |
| display | 64px | 1.0 |

(48px is also used for display variants.)

## Spacing & Shapes

Base unit 4px. Scale: 4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 128, 156px.
Radius: buttons/tags 6px · inputs 10px · wash cards 12px · content cards 16px. Never 4px or fully-rounded pills.
Layout: max-width 1200px · section gap 64–128px · card padding 20–24px · element gap 8px.

## Components

- **Primary button:** #e4f222 fill, #0c0a08 text, 6px radius, 20px horizontal padding, ~44px tall. Only chromatic button.
- **Outlined button:** transparent, 1px Ink border, Ink text, 6px radius.
- **Ghost/link button:** transparent, hover → #f4f2f0.
- **Square icon button:** 16px padding, #f4f2f0, 12px radius.
- **Content card:** #fff, 1px #e5e7eb border, 16px radius, 20px padding, no shadow — border is the elevation.
- **Wash card:** #f4f2f0, 12px radius, no border.
- **Email input:** 10px radius, 1px rgba(33,33,33,0.1) border, flush beside the primary button.
- **Testimonial card:** content card + square logo badge, name/title 16px/400, quote in Ink.
- **Live counter ticker:** full-width #1a1919 band, 10px uppercase Ash labels, 14px white metric values.
- **Sticky nav:** white, 1px bottom border, 102px with 40px announcement bar.
- **Logo grid:** 7-column hairline-bordered cells, grayscale logos.
- **Hero product screenshot:** browser-chrome frame, shadow-free white panels.

## Do's and Don'ts

### Do
- lausanne 400 exclusively — hierarchy from size and tracking.
- #e4f222 only for primary action fills, live counters, active states.
- Card elevation via 1px #e5e7eb border on white.
- Display headlines at 64/48/40px with line-height ≤ 1.05.
- +0.018em tracking on 10px uppercase micro-labels.
- Radii: 6 / 10 / 12 / 16px only.
- Left-align content inside centered max-width containers.

### Don't
- No additional chromatic accents.
- No bold or semibold weights.
- No box-shadow on cards, modals, panels.
- Don't use #0c0a08 as a large section background — use #1a1919 for inverted panels.
- Don't center body text or headlines.
- No decorative gradients, illustrations, or stock photography.
- No pill-shaped UI elements.

## Surfaces

| Level | Name | Value |
|-------|------|-------|
| 1 | Canvas | `#f4f2f0` |
| 2 | Card | `#ffffff` |
| 3 | Wash | `#f4f2f0` |
| 4 | Inverted | `#1a1919` |
| 5 | Action | `#e4f222` |

Elevation: hairline borders and tonal shifts (Bone → White → Inverted); no shadows.

## Imagery

No photography or lifestyle imagery. Product screenshots in browser-chrome frames, grayscale customer logos, one dark brand-moment image. Filled mono-colored minimal icons. Everything reads as a screenshot or a typographic statement.

## Layout

Light canvas with ~1200px centered columns. Hero: left-aligned 64px headline + 24px subhead + composite input+button over a large product screenshot bleeding right. Alternates light editorial bands (64–128px padding) with one full-bleed dark band. 2-column text/visual pairs; 7-column logo grid; 4-column testimonial scroll. Editorial-publication feel.

## Signature Design Choices

1. Single-weight typography — headlines like editorial pull-quotes.
2. One chromatic accent rule — chartreuse only on action surfaces.
3. Hairline borders over shadows.
4. Tight display leading + airy uppercase micro-labels.
5. `ss01` font feature always on.

## Motion
0.3–0.4s ease-out on color/background/border changes; no transform theatrics.

## Agent Prompt Guide

- text #0c0a08 · background #f4f2f0 · card #ffffff · border #e5e7eb · muted #6d6c6b · primary action #e4f222.
- Hero: 64px/400 Ink on Bone, line-height 1.0; 24px Ash subhead; composite email input + highlighter button.
- Card: #fff, 1px #e5e7eb, 16px radius, 20px padding, no shadow.

## Similar Brands
Linear · Stripe · Notion · Substack · Brex

## Quick Start (CSS)

```css
:root {
  --color-highlighter: #e4f222; --color-ink: #0c0a08; --color-obsidian: #1a1919;
  --color-paper: #ffffff; --color-bone: #f4f2f0; --color-ash: #6d6c6b; --color-hairline: #e5e7eb;
  --font-lausanne: 'Inter', system-ui, sans-serif; --font-feature-settings: "ss01";
  --text-display: 64px; --text-h1: 40px; --text-h2: 28px; --text-h3: 24px; --text-body: 16px; --text-caption: 10px;
  --radius-button: 6px; --radius-input: 10px; --radius-wash: 12px; --radius-card: 16px;
  --page-max-width: 1200px;
}
```
