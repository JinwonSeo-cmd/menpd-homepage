# Wise — Style Reference
> deep moss with lime voltage. Lime sparks on a near-black forest floor, with massive blocky display type announcing every move.

**Theme:** light

Wise speaks in a confident, slightly loud voice: a deep forest green (#163300) carries most of the surface area — text, nav, dark sections, icons — while a single electric lime (#9fe870) acts as functional punctuation on CTAs, active tabs, and key highlights. The display type is almost aggressive: Wise Sans at weight 900, tightly tracked, shouted across the hero in 100px+ block letters. The rest of the system stays restrained on a near-white canvas with soft gray surfaces (#e8ebe6). Components are pill-shaped by default — buttons, nav segments, flag thumbnails, image masks — with gentle 10px radii reserved for cards and inputs. Color rarely gradients; instead, the lime–forest pairing inverts cleanly when sections go dark, creating rhythm without decoration.

## Tokens — Colors

| Name | Value | Token | Role |
|------|-------|-------|------|
| Forest Ink | `#163300` | `--color-forest-ink` | Dominant brand dark — nav text, dark section backgrounds, primary copy on light surfaces, icon strokes, filled navigation pills. The brand's gravity: wherever you need weight or authority |
| Lime Voltage | `#9fe870` | `--color-lime-voltage` | Accent for CTAs, active states, key highlights. Fill only, or text on dark green |
| Spruce | `#054d28` | `--color-spruce` | Secondary dark green for card surfaces, supporting iconography, tonal depth on dark sections |
| Linen Mist | `#e2f6d5` | `--color-linen-mist` | Pale green wash for soft highlight surfaces, tinted cards, hover states |
| Signal Blue | `#0b4c72` | `--color-signal-blue` | Blue supporting accent, low-frequency |
| Alarm Red | `#cb272f` | `--color-alarm-red` | Red supporting accent, low-frequency |
| Charcoal | `#454745` | `--color-charcoal` | Primary text, body copy, dense UI |
| Obsidian | `#0e0f0c` | `--color-obsidian` | Display headlines, high-contrast headings. Green-tinted black |
| Pebble | `#868685` | `--color-pebble` | Muted secondary text, placeholder, input borders |
| Slate | `#6a6c6a` | `--color-slate` | Supporting body text, helper labels |
| Fog | `#e8ebe6` | `--color-fog` | Card surfaces, dividers, subtle panels |
| Paper | `#ffffff` | `--color-paper` | Page canvas, inverted card surfaces, button text on lime fill |

## Tokens — Typography

### Inter — Body, UI, labels, sub-headings · `--font-inter`
- **Weights:** 400,500,600,700
- **Sizes:** 12, 14, 16, 18, 20, 22, 25, 36, 45, 61px
- **Letter spacing:** -0.030em at 105px, -0.015em at 61px, -0.011em at 36px, -0.009em at 25px, -0.007em at 18px, -0.006em at 16px, -0.005em at 14px, -0.003em at 12px
- **Role:** 700 for mid-tier headings (36–45px), 500–600 for subheadings and labels, 400 for body and captions. Inter does the quiet work while Wise Sans shouts.

### Wise Sans — Display headlines · `--font-wise-sans`
- **Substitute:** Inter Black (900) with -0.04em tracking
- **Weights:** 900
- **Sizes:** 40, 52, 59, 89, 105px
- **Line height:** 0.85
- **Role:** The brand's signature shout. Weight 900 at 89–105px with tight -0.03em tracking. Used sparingly: hero, section openers, campaign moments.

### Type Scale

| Role | Size | Line Height | Letter Spacing |
|------|------|-------------|----------------|
| micro | 12px | 1.63 | -0.036px |
| caption | 14px | 1.55 | -0.07px |
| body-sm | 16px | 1.5 | -0.096px |
| body | 18px | 1.5 | -0.126px |
| body-lg | 25px | 1.3 | -0.225px |
| subheading | 36px | 1.25 | -0.396px |
| heading-sm | 45px | 1.1 | -0.495px |
| heading | 61px | 1.1 | -0.915px |
| heading-lg | 89px | 0.85 | -2.67px |
| display | 105px | 0.85 | -3.15px |

## Tokens — Spacing & Shapes

**Base unit:** 4px · **Density:** comfortable
**Spacing scale:** 4, 8, 12, 16, 20, 24, 28, 32, 40, 44, 48, 56, 64, 100, 124px

### Border Radius

| Element | Value |
|---------|-------|
| tags / buttons / navSegments | 9999px |
| cards / inputs | 10px |
| imageMasks | 1000px |
| largeCards | 28px |

### Shadows

| Name | Value |
|------|-------|
| subtle | `rgba(14, 15, 12, 0.12) 0px 0px 0px 1px` |
| lg | `rgba(0, 0, 0, 0.08) 0px 6px 20px 0px` |
| xl | `rgba(0, 0, 0, 0.15) 0px 10px 32px 0px, rgba(0, 0, 0, 0.04) 0px 40px 40px 0px` |

### Layout

- **Page max-width:** 1200px · **Section gap:** 64-80px · **Card padding:** 24px · **Element gap:** 8-12px

## Components

### Primary CTA Pill Button
Filled lime pill that signals "do this next." 9999px radius, Lime Voltage fill, Charcoal or Forest Ink text. Padding 11px/24px. Inter 500 16px. No border, no shadow.

### Outlined Pill Button
Secondary action. White fill, 1px Forest Ink border, 9999px radius, same padding.

### Text Link Button
Underlined Forest Ink text, Inter 500 16px. Pairs with the primary CTA.

### Top Navigation Bar
White, 64px. Logo left, three-segment pill nav, right cluster with outlined Sign up pill.

### Segmented Tab Control
Pill container; active tab Lime Voltage fill with Charcoal text; inactive transparent. ~40px height.

### Display Headline
Wise Sans 900 at 89–105px, line-height 0.85, letter-spacing -3.15px. Charcoal/Obsidian on light, Lime Voltage on dark sections. Block text, often ALL CAPS.

### Feature Row
Three columns: icon 24px Charcoal stroke, heading Inter 700 18px, body Inter 400 16px Pebble. 24px gap between icon and heading.

### Dark Section Card
Forest Ink background, 28px radius, 40px padding. Lime Voltage headline, Paper body. May contain an inset white card (10px radius).

### Input Field
10px radius, 1px Pebble border, 12px/16px padding, Inter 400 16px. Focus: Forest Ink border, no glow.

### Badge / Tag
9999px radius, 8px/12px padding. Linen Mist bg + Forest Ink text, or Forest Ink bg + Lime Voltage text. Inter 500 12px.

## Do's and Don'ts

### Do
- Set display headlines in Wise Sans 900 with -3.15px letter-spacing at 105px; the extreme heaviness is the signature — don't soften it to 700.
- Use Lime Voltage exclusively for primary action fills and active states; one lime element per visible section is usually enough.
- Default to 9999px radius for buttons, tags, nav segments.
- Use Forest Ink (#163300) for text and dark surfaces, not pure black.
- Apply tight negative letter-spacing at large sizes; headings should feel compact.
- Pair a filled primary CTA with an underlined text link as secondary — never two filled buttons side by side.
- Invert section backgrounds from white to Forest Ink for rhythm; lime text on dark green is the built-in emphasis.

### Don't
- Don't use Charcoal for display headlines — use Obsidian or Forest Ink.
- Don't introduce gradients, drop shadows beyond hairline borders, or decorative blurs — flat by design.
- Don't use Lime Voltage as text color on light backgrounds (low contrast).
- Don't use sharp corners (0–4px) on buttons, tags, or nav.
- Don't set 60px+ display type in Inter.
- Don't stack multiple lime elements close together.
- Don't use #000000 for body text; Charcoal at 18px on white is the baseline.

## Surfaces

| Level | Name | Value | Purpose |
|-------|------|-------|---------|
| 0 | Paper | `#ffffff` | Page canvas |
| 1 | Fog | `#e8ebe6` | Cards, soft panels |
| 2 | Linen Mist | `#e2f6d5` | Tinted highlight surfaces |
| 3 | Lime Voltage | `#9fe870` | Active surface — tabs, CTA, emphasis |
| 4 | Forest Ink | `#163300` | Inverted surface — dark sections |

## Imagery

Painted 3D-style illustrations (globe with gold coins) — tactile, slightly surreal, soft gradients, warm light. Photography minimal, high-key, lifestyle-casual. Circular flag thumbnails as the only icon system. No abstract graphics or stock patterns.

## Layout

Max-width 1200px centered, hero and dark sections full-bleed. Hero: centered massive display headline over white space with a large illustration breaking the lower edge. Section rhythm alternates white → light green band → dark Forest Ink. Centered stacks in hero, then 2-column text+visual or 3-column feature rows.

## Agent Prompt Guide

- text: #454745 body, #0e0f0c display
- background: #ffffff canvas, #e8ebe6 cards
- border: #868685 hairlines, #163300 emphasis
- accent: #9fe870 for active states and highlights
- dark surface: #163300 for inverted sections

## Quick Start (CSS)

```css
:root {
  --color-forest-ink: #163300; --color-lime-voltage: #9fe870; --color-spruce: #054d28;
  --color-linen-mist: #e2f6d5; --color-signal-blue: #0b4c72; --color-alarm-red: #cb272f;
  --color-charcoal: #454745; --color-obsidian: #0e0f0c; --color-pebble: #868685;
  --color-slate: #6a6c6a; --color-fog: #e8ebe6; --color-paper: #ffffff;
  --font-inter: 'Inter', system-ui, sans-serif;
  --font-wise-sans: 'Wise Sans', 'Inter', system-ui, sans-serif;
  --spacing-unit: 4px; --page-max-width: 1200px;
  --radius-card: 10px; --radius-large: 28px; --radius-pill: 9999px;
}
```
