# Figma — Style Reference
> white gallery wall with a single indigo spotlight.

**Theme:** light

A pure white canvas for creativity: an achromatic interface where black text, white surfaces, and a single electric indigo accent do all the work. The system stays out of the way so the work can speak — ultra-light display headlines, light body text, pill-shaped controls. Color appears only as functional punctuation (CTA, hover states, the logo) and as pastel/illustration fills that belong to the content, not the chrome. Elevation is one soft drop shadow on the hero floating card; everything else is whitespace, weight contrast, and scale. Museum-meets-workspace rhythm: vast breathing-room sections alternating with tight card grids.

## Tokens — Colors

| Name | Value | Role |
|------|-------|------|
| Ink Black | `#000000` | Primary text, strokes, ghost-button borders |
| Paper White | `#ffffff` | Canvas, cards, ghost button fills |
| Soft Mist | `#e2e2e2` | Secondary panel backgrounds |
| Graphite | `#595959` | Muted helper text, metadata |
| Electric Indigo | `#4d49fc` | Primary CTA, active nav — the only saturated action color |
| Figma Cyan / Green / Orange | `#00b6ff` / `#24cb71` / `#ff7237` | Logo marks only |
| Lime Wash | `#e4ff97` | Decorative pastel fill (illustration only) |
| Lilac | `#c4baff` | Decorative pastel fill |
| Blush | `#ffc9c1` | Decorative pastel fill |
| Aqua Mist | `#c7f8fb` | Decorative pastel fill |
| Earworm Teal / Mustard | `#33dfdf` / `#b98e01` | Decorative ring strokes |

## Tokens — Typography

- **figmaSans** (substitute: Inter, variable weights) — all UI. Hero/section headlines at weight **320–340** (ultra-light, whispered authority); body 400; buttons 480; card titles 520; 700 only for tight labels/nav. Tracking -0.02em at 72px → -0.007em at 16px.
- **figmaMono** (substitute: JetBrains Mono) — code and annotations only; +0.03 to +0.05em tracking.

| Role | Size | Line Height | Tracking |
|------|------|-------------|----------|
| caption (mono) | 12px | 1.3 | 0.48px |
| body-sm | 16px | 1.45 | -0.11px |
| body | 18px | 1.4 | -0.18px |
| heading | 24px | 1.35 | -0.24px |
| heading-lg | 56px | 1.1 | -0.84px |
| display | 72px | 1.1 | -1.44px |

## Spacing & Shapes

Base unit 4px. Scale: 4, 8, 12, 16, 20, 24, 32, 40, 48, 56, 60, 64, 80, 120, 180px.
Four-tier radius, never mixed: **2px** fine UI · **8px** ghost buttons/inputs/tags · **16px** cards · **50px** pill (primary buttons and chips only).
Layout: max-width 1200px · section gap 80–120px · card padding 16–24px · element gap 12–16px.
Shadow (hero floating card only): `rgba(0,0,0,0.1) 0 24px 70px 0`.

## Components

- **Hero floating card:** white, 16px radius, 24px padding, the signature soft shadow; 56px/320 headline; floats over a scattered collage.
- **Primary CTA:** #4d49fc fill, white 16px/480, 50px pill, padding 10px 20px — the only "switched-on" element.
- **Ghost button:** transparent, 1px black border, 8px radius, 16px/400.
- **Black pill button:** #000 fill, white text, 50px radius (header CTA).
- **Top nav:** white, 64px, no border/shadow; logo left, links center, auth right.
- **Hero collage:** slightly rotated, overlapping real design work in full color — proof of capability.
- **Community card grid:** 4 columns, 24px gaps, white, no border/shadow, 16px radius; 18px/520 title, 14px/400 Graphite creator with avatar.
- **Product feature panel:** large product screenshot with no card chrome; 18px caption max-width ~600px.
- **Section headline:** 56px/320, -0.84px tracking, left-aligned, no subtitle.
- **Decorative ring:** thin conic-gradient ring (teal → mustard), never interactive.

## Do's and Don'ts

### Do
- Indigo for exactly one CTA per viewport.
- Hero headlines 56–72px at weight 320–340 — the signature.
- 50px pill for primary buttons and chips; 8px for ghost/inputs; 16px for cards; 2px for fine UI.
- Black on white for contrast; Graphite only for de-emphasized metadata.
- figmaMono with positive tracking for code/annotations only.
- Let galleries and screenshots carry all the decorative color; keep chrome achromatic.

### Don't
- No color fills on secondary buttons — black outline ghost is correct.
- No weights above 520 for body/headings (700 for tight labels only).
- No drop shadows on grid cards — the one big shadow is for the hero card.
- No 50px radius on cards or inputs.
- Don't introduce new chromatic UI colors; logo colors stay in the logo, pastels stay in illustration.
- No body text under 16px (mono 12px is annotation-only).
- No tracking outside -0.02em to +0.05em.

## Surfaces & Elevation

| Level | Name | Value |
|-------|------|-------|
| 1 | Canvas | `#ffffff` |
| 2 | Card | `#ffffff` (separated by shadow/border only) |
| 3 | Soft Panel | `#e2e2e2` |

## Imagery

Let users do the work: a 2D-scattered collage of real community designs (posters, app screens, editorial layouts, 3D renders) in full color at full scale; below, product screenshots with the app's own UI chrome; a gallery of uncropped thumbnails. No stock, no lifestyle photography, no people — the work IS the imagery.

## Layout

1200px centered column on fluid white. Full-width hero: scattered collage behind a centered floating card (~60% page width) → quiet product showcase → 4-column gallery. 80–120px whitespace bands with left-aligned display headlines. Sparse, museum-paced, never dense. Flat 64px top bar; no sidebar or mega-menu.

## Color Discipline

The UI is 0% colorful: black, white, one indigo. Every other color is (1) a logo marker, (2) decorative user work, or (3) a conic ring accent. Never inject decorative colors into UI components — the page is a white gallery; the work on the page is the color.

## Agent Prompt Guide

- background #ffffff · text #000000 · border #000000 · muted #595959 · accent/primary action #4d49fc.
- Hero card: white, 16px radius, 24px padding, shadow `0 24px 70px rgba(0,0,0,0.1)`, 56px/320 headline at -0.84px, 18px #595959 subtext; collage of rotated colorful posters behind.
- Section headline: 56px/320, line-height 1.1, left-aligned, no subtitle — don't bold it.

## Similar Brands
Linear · Notion · Vercel · Framer · Stripe

## Quick Start (CSS)

```css
:root {
  --color-ink: #000000; --color-paper: #ffffff; --color-mist: #e2e2e2; --color-graphite: #595959;
  --color-indigo: #4d49fc;
  --color-lime-wash: #e4ff97; --color-lilac: #c4baff; --color-blush: #ffc9c1; --color-aqua-mist: #c7f8fb;
  --font-sans: 'figmaSans', 'Inter', system-ui, sans-serif; --font-mono: 'figmaMono', 'JetBrains Mono', monospace;
  --weight-display: 320; --weight-body: 400; --weight-button: 480; --weight-card-title: 520;
  --text-display: 72px; --text-h1: 56px; --text-h2: 24px; --text-body: 18px; --text-body-sm: 16px;
  --radius-fine: 2px; --radius-small: 8px; --radius-card: 16px; --radius-pill: 50px;
  --shadow-float: 0 24px 70px rgba(0,0,0,0.1); --page-max-width: 1200px;
}
```
