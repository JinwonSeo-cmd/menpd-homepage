# teenage engineering — Style Reference
> industrial catalogue under studio light — the product is the only rich object on the page and everything else is whispered around it

**Theme:** light

An industrial product catalogue rendered in typographic whispers: a near-white canvas (#f6f8f7) hosts photographed products on seamless studio backdrops, while everything else — nav, body copy, borders, labels — sits in ultra-thin weight 100 type that almost disappears. Contrast comes from material, not ornament: products are the only dense visual objects; the UI is negative space, hairline rules, and one occasional dark band (#0f0e12) like a display-case wall. Zero rounded corners, zero shadows, zero gradients — every edge is a straight cut. Color is rationed: black text, gray hairlines, a violet-tinted near-black for inverted sections, and a single chromatic note (amber warning triangle).

## Tokens — Colors

| Name | Value | Role |
|------|-------|------|
| Canvas Mist | `#f6f8f7` | Page background, dominant surface |
| Ink Black | `#000000` | Body text, hairline borders, rules — the typographic anchor |
| Carbon | `#0f0e12` | Dark hero bands, footer, inverted sections (violet-cast near-black, never pure #000) |
| Steel Gray | `#e5e5e5` | Light hairlines, dividers |
| Graphite | `#b2b2b2` | Muted secondary text, quiet borders, labels on dark |
| Link Blue | `#0071bb` | Text links only |
| Warning Amber | `#f0a800` | The only chromatic note — warning states only |

## Tokens — Typography

- **te-20** (substitute: Inter weight 100/300 or Suisse Int'l Thin) — nearly everything. Weight **100** at 13px is body default; weight 300 for 19px and up (nav, labels, mid-size UI).
- **te-40** (substitute: Inter 300) — primary page headings at exactly 40px, weight 300, line-height 1.11.

| Role | Size | Line Height |
|------|------|-------------|
| caption/body | 13px | 1.5 |
| subheading | 19px | 1.15 |
| heading-sm | 24px | 1.15 |
| heading | 26px | 1.15 |
| heading-lg | 40px | 1.11 |

Letter spacing normal. Never exceed weight 300. Text always left-aligned.

## Spacing & Shapes

Spacing: 15 · 22 · 33 · 66px. Section gap 66px, element gap 15px, card padding 0. Max-width 1200px.
Border radius: **0px everywhere** (cards, buttons, inputs, tags).

## Components

- **Top nav:** ~66px, no fill, 1px #e5e5e5 bottom border; lowercase wordmark te-20/300 24px left; icon+label entries right with 15px gaps.
- **Product grid card:** 3 columns, image edge-to-edge (no padding/border/radius), name 13px/100 below, link in blue; 22px gutters with 1px #e5e5e5 vertical rules. The photograph IS the card.
- **Dark hero band:** full-bleed #0f0e12, single product at 3/4 perspective with generous margin, small label bottom-left in #b2b2b2 13px. No overlay UI, no gradient.
- **Text link:** 13px/100, #0071bb, no underline until hover.
- **Footer block:** #0f0e12, 33px vertical padding, 13px/100 #f6f8f7 links.
- **Icon glyph:** ~20px square line drawings, hairline stroke matching type weight.
- **Warning triangle:** amber triangle with black icon; solid black "accept" button, 0px radius.

## Do's and Don'ts

### Do
- Weight 100 as the default for body, labels, links, meta; 300 only at 19px+ and headings.
- Let product photography fill the grid cell edge-to-edge — the product is the card.
- 66px section gaps, 15px element gaps.
- Use #0f0e12 (not #000) for dark bands and inverted sections.
- Keep the palette to five neutrals; add a sixth color only for a state (warning/error).
- 0px radius on every component.
- Organize with 1px hairline rules (#e5e5e5 or #000) rather than fills or shadows.

### Don't
- No border-radius above 0.
- No drop shadows, glows, or inset shadows — elevation = light/dark band contrast.
- No weights above 300.
- No gradients in UI.
- No running text below 13px or above 19px.
- No color as decoration.
- No centered body paragraphs.
- No padding inside product image cells.

## Surfaces & Elevation

| Level | Name | Value |
|-------|------|-------|
| 1 | Canvas Mist | `#f6f8f7` |
| 2 | Pure White (image islands) | `#ffffff` |
| 3 | Carbon | `#0f0e12` |

Zero shadows. Importance is expressed by placing the product on the dark Carbon plane. Hairlines (1px #e5e5e5/#000) replace shadows as the organizing device, like lines on a technical drawing.

## Imagery

High-key product photography on seamless white/gray studio backdrops at 3/4 angles; no lifestyle, no models, no illustration, no decorative graphics. The only non-product visuals are hairline nav icons. The product is the design system.

## Layout

1200px centered column on #f6f8f7. Thin top nav → full-bleed dark hero band with one product → 3-column product grid with vertical hairline rules → dark footer. Paginated technical-catalogue feel, left-aligned, not sticky, no sidebar/mega-menu.

## Agent Prompt Guide

- text #000000 · background #f6f8f7 · border #e5e5e5 · dark surface #0f0e12 · muted #b2b2b2 · link #0071bb · no CTA color.
- Grid card: image edge-to-edge, 13px/100 name below, blue "buy now" link, 1px #e5e5e5 right rule, 22px gap.
- Dark band: full-bleed #0f0e12, product centered with 66px top/bottom padding, 13px #b2b2b2 label bottom-left.

## Similar Brands
Nothing · Punkt. · Braun · Areaware · HOTO Tools

## Quick Start (CSS)

```css
:root {
  --color-canvas: #f6f8f7; --color-ink: #000000; --color-carbon: #0f0e12;
  --color-hairline: #e5e5e5; --color-muted: #b2b2b2; --color-link: #0071bb;
  --font-te: 'Inter', 'Suisse Int\'l', system-ui, sans-serif;
  --weight-thin: 100; --weight-light: 300;
  --text-caption: 13px; --text-sub: 19px; --text-h3: 24px; --text-h2: 26px; --text-h1: 40px;
  --spacing-15: 15px; --spacing-22: 22px; --spacing-33: 33px; --spacing-66: 66px;
  --radius: 0px; --page-max-width: 1200px;
}
```
