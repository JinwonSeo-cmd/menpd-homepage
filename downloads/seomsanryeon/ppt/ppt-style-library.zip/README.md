# md 샘플 (refero 디자인 스타일 10종)
출처: https://styles.refero.design/ — 각 스타일의 DESIGN.md를 봇 컨텍스트용으로 정리(Tailwind 중복 블록 제외, 02~10번은 요약본).
01 Brex · 02 Wise · 03 Notion · 04 Raycast · 05 teenage engineering · 06 Mercury · 07 Ramp · 08 Ui(shadcn) · 09 Integrated Biosciences · 10 Figma
