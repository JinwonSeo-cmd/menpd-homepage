# Ui (shadcn/ui) — Style Reference
> clinical blueprint on frosted paper

**Theme:** light

A monochromatic design-system workshop: pure white canvas, soft warm-gray surfaces, and large-radius cards floating on hairline borders. Almost entirely achromatic — black text, white surfaces, gray secondary tones — with a single red reserved for destructive/error states. Typography leans on Geist's geometric neutrality with tight letter-spacing on display sizes, a quiet code-adjacent feel that reads as developer infrastructure rather than consumer product.

## Tokens — Colors

| Name | Value | Role |
|------|-------|------|
| Canvas | `#f5f5f5` | Page background, muted fills, secondary buttons, resting inputs |
| Paper | `#ffffff` | Card surfaces, popovers |
| Surface Alt | `#fafafa` | Sidebar background, subtle card variant |
| Ink | `#0a0a0a` | Primary text, headings, filled button background, icons |
| Ink Soft | `#171717` | Solid badge fill, secondary text |
| Mid Gray | `#737373` | Muted body text, placeholders, helper labels |
| Hairline | `#e5e5e5` | Borders, input outlines, card edges |
| Ember | `#e7000b` | Destructive/error only |

## Tokens — Typography

**Geist** (substitute: Inter), features `"ss01"`, `"cv11"`. Body 14px/400; headings 24–48px/600; buttons 13–14px/500.
Tracking: -0.05em at 48px display, -0.025em at 24–30px, +0.05em on 12px uppercase captions. Never wider than 0.05em or tighter than -0.05em.

| Role | Size | Line Height | Tracking |
|------|------|-------------|----------|
| caption | 12px | 1.33 | 0.6px |
| body | 14px | 1.43 | — |
| body-lg | 16px | 1.5 | — |
| subheading | 18px | 1.56 | — |
| heading-sm | 24px | 1.33 | -0.6px |
| heading | 30px | 1.2 | -0.75px |
| heading-lg | 36px | 1.11 | -0.9px |
| display | 48px | 1.1 | -2.4px |

## Spacing & Shapes

Base unit 4px, compact. Scale: 4, 8, 12, 16, 20, 24, 48px.
Radius: **18px** for interactive (buttons, inputs, badges) · **24px** for containers (cards) · 10px nested · 6px small. Nothing in between; no square corners.
Layout: max-width 1280px · section gap 48–80px · card padding 20px · element gap 8px.

## Components

- **Primary filled button:** #0a0a0a bg, #fafafa text, 18px radius, 14px/500, ~36–40px tall. No shadow — tonal contrast only.
- **Secondary ghost button:** #f5f5f5 bg, Ink text, same shape and size.
- **Outline button:** transparent, 1px #e5e5e5 border.
- **Card:** #fff, 24px radius, 1px #e5e5e5 border, shadow `0 0 0 1px rgba(23,23,23,.05), 0 1px 3px rgba(0,0,0,.1), 0 1px 2px -1px rgba(0,0,0,.1)`, 20px padding.
- **Nested card header/footer:** transparent strips with 24px outer corners, 20px horizontal padding.
- **Input:** #f5f5f5 at rest, 18px radius, no border; focus = 1px #e5e5e5 ring.
- **Badges:** solid (#171717/#fafafa), soft (#f5f5f5/#171717), outline; 18px radius, 12px/500.
- **Sidebar:** #fafafa, one tonal step off canvas, no divider.
- **Breadcrumb:** 14px, #737373 separators, Ink current segment.
- **Stat block:** 12–14px uppercase #737373 label, 30–48px/600 value, no card chrome.
- **Search trigger:** #f5f5f5 pill with ⌘K hint.
- **Destructive action:** #e7000b text/icon — the only chromatic hue.

## Do's and Don'ts

### Do
- Dark filled buttons (#0a0a0a) as the only primary-action treatment.
- 18px radius on all interactive elements; 24px on cards only.
- Display headlines 48px/600, -0.05em tracking.
- Reserve #e7000b for destructive states.
- Cards: 1px hairline border plus the three-layer faint shadow.
- Three-tone surface stack (canvas → soft → paper) for layering without borders.

### Don't
- No chromatic brand colors beyond #e7000b.
- No radii other than 18px/24px (plus 10px nested, 6px small).
- Don't skip the 1px hairline on cards.
- No body text below 14px or lighter than #737373.
- No gradients, colored shadows, or accent fills — every surface is a solid tone.
- No tracking outside ±0.05em.
- Don't place same-size filled and outline buttons in one row without a ghost/secondary variant between.

## Surfaces & Elevation

| Level | Name | Value |
|-------|------|-------|
| 0 | Canvas | `#f5f5f5` |
| 1 | Sidebar | `#fafafa` |
| 2 | Card | `#ffffff` |
| 3 | Input fill | `#f5f5f5` |

Card elevation is a whisper (see Card). Filled buttons: none. Input focus: 1px #e5e5e5 ring.

## Imagery

Minimal — the system is the UI. No photography, illustration, or decorative graphics. Showcases are component mockups in a grid; icons are thin-stroke (1.5–2px, Lucide-like) in Ink or Mid Gray. The page is a living style guide where every element is a visible design token.

## Design Philosophy

(1) Achromatic by default — color is absence, not expression. (2) Radius defines hierarchy — 18px interactive, 24px containers. (3) Elevation is whisper-quiet — hairlines and tonal contrast, not dramatic shadows. Every value is explicit and simple.

## Agent Prompt Guide

- canvas #f5f5f5 · card #ffffff · text #0a0a0a · muted #737373 · border #e5e5e5 · primary action #171717 · destructive #e7000b.
- Stat card: white, 24px radius, 1px #e5e5e5, layered faint shadow, 20px padding; 12px uppercase #737373 label, 36px/600 value, -0.025em tracking.
- Badge: #171717 bg, #fafafa text, 18px radius, 2px 8px padding, 12px/500.

## Similar Brands
Vercel · Linear · Radix UI · Tailwind UI · Cal.com

## Quick Start (CSS)

```css
:root {
  --color-canvas: #f5f5f5; --color-paper: #ffffff; --color-surface-alt: #fafafa;
  --color-ink: #0a0a0a; --color-ink-soft: #171717; --color-mid-gray: #737373;
  --color-hairline: #e5e5e5; --color-destructive: #e7000b;
  --font-geist: 'Geist', 'Inter', system-ui, sans-serif;
  --radius-interactive: 18px; --radius-card: 24px; --radius-nested: 10px;
  --shadow-card: 0 0 0 1px rgba(23,23,23,.05), 0 1px 3px rgba(0,0,0,.1), 0 1px 2px -1px rgba(0,0,0,.1);
  --page-max-width: 1280px; --card-padding: 20px;
}
```
