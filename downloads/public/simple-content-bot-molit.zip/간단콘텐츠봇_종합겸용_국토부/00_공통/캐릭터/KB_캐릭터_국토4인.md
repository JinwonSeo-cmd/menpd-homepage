# 캐릭터 — 국토 4인 (국토교통부 공무원)

외모는 `_참고_법무부4인/`의 같은 성 캐릭터와 **얼굴·헤어·체형·3D 치비 그림체를 그대로 유지**하고, 소속과 소품만 국토교통부로 바꾼다.
시트가 완성되면 `김국토.png` 등으로 저장된 이미지를 기준으로 삼는다.

| 캐릭터 | 나이·직급 | 성격 한 줄 | 말투 예 | 잘 맞는 주제 | 시그니처 소품·동작 |
|---|---|---|---|---|---|
| 김국토 | 25세 · 신입 | 호기심 많고 리액션 큰 열정 막내 | "어? 이거 저도 몰랐어요!" | 생활 교통 꿀팁, 처음 알면 놀랄 제도 | 노란 안전모를 옆구리에 낌, 수첩 메모, 엄지척 |
| 박국토 | 27세 · 2년차 | 차분하고 다정한 공감형 상담가 | "괜찮아요, 이렇게 확인하시면 돼요." | 청년·신혼 주거 지원, 전세 안전 | 집 모양 아이콘 서류철, 고개 끄덕 |
| 서국토 | 40세 · 아저씨 | 유쾌한 아재, 비유와 아재개그 담당 | "이건 마치 내비 없이 운전하는 거죠!" | 전세사기 예방, 교통안전 캠페인 | 지도·자동차 무늬 하와이안 셔츠, 손가락 총, 윙크 |
| 최국토 | 40세 · 팀장 | 결론부터 말하는 원칙주의자 | "핵심만 말씀드리면, 두 가지입니다." | 법·제도 개정, 건설 안전 기준 | 안경 고쳐 쓰기, 도면 태블릿, 손가락으로 숫자 세기 |

## 조합
- 김 + 최 : 신입이 묻고 팀장이 정리 → 정보 전달형
- 서 + 박 : 아재개그로 판을 열고 차분히 수습 → 유쾌하면서 믿음직한 톤

## 공통 복장
- 목에 하늘색 공무원증 목걸이(줄에 작은 글씨 "국토교통부"), 가슴에 작은 네이비 배지
- 로고는 그리지 않는다 (나중에 합성)

## 시트 만들기 프롬프트 (구글 플로우 · 참고 이미지 1장 첨부 · 각각 완결형)

### 김국토 (첨부 : _참고_법무부4인/김법무.png)
Using the attached character sheet as the exact reference, keep the same face, hairstyle, body proportions and cute 3D chibi Pixar-like render style. Create a new full character reference sheet on a soft light-blue gradient background. Big bold navy Korean title at top left: "김국토", small subtitle: "25세 · 국토교통부 공무원". Character: 25-year-old male new civil servant, white shirt with navy tie, navy slacks, black shoes, sky-blue ID lanyard with tiny text "국토교통부", holding a yellow safety helmet under his arm. Layout: large full-body pose on the left (arms crossed, confident smile); top row of six small poses with Korean labels "정면", "측면", "후면", "인사 포즈", "서류 들기 포즈", "메모하는 포즈"; bottom row of six face close-ups with Korean labels "행복한 표정", "진지한 표정", "놀란 표정", "걱정한 표정", "결의에 찬 표정", "부끄러운 표정". Clean studio lighting, consistent character across all views, 16:9, no logos.

### 박국토 (첨부 : _참고_법무부4인/박법무.jpg)
Using the attached character sheet as the exact reference, keep the same face, ponytail hairstyle, body proportions and cute 3D chibi Pixar-like render style. Create a new full character reference sheet on a soft light-blue gradient background. Big bold navy Korean title at top left: "박국토", small subtitle: "27세 · 국토교통부 공무원". Character: 27-year-old female civil servant, light-blue shirt, beige slacks, brown shoes, sky-blue ID lanyard with tiny text "국토교통부", holding a navy file folder with a small house icon on the cover. Layout: large full-body pose on the left (gentle smile, holding the folder); top row of six small poses with Korean labels "정면", "측면", "후면", "인사 포즈", "서류 들기 포즈", "메모하는 포즈"; bottom row of six face close-ups with Korean labels "행복한 표정", "진지한 표정", "놀란 표정", "걱정한 표정", "결의에 찬 표정", "부끄러운 표정". Clean studio lighting, consistent character across all views, 16:9, no logos.

### 서국토 (첨부 : _참고_법무부4인/서법무.jpg)
Using the attached character sheet as the exact reference, keep the same face, short graying hairstyle, body proportions and cute 3D chibi Pixar-like render style. Create a new full character reference sheet on a soft light-blue gradient background. Big bold navy Korean title at top left: "서국토", small subtitle: "40세 · 국토교통부 공무원". Character: 40-year-old cheerful male civil servant, colorful Hawaiian shirt whose pattern is made of tiny road maps, cars, trains and airplanes, gray slacks, sneakers, sky-blue ID lanyard with tiny text "국토교통부". Layout: large full-body pose on the left (arms crossed, playful grin); top row of six small poses with Korean labels "정면", "측면", "후면", "인사 포즈", "서류 들기 포즈", "메모하는 포즈"; bottom row of six face close-ups with Korean labels "행복한 표정", "진지한 표정", "놀란 표정", "걱정한 표정", "결의에 찬 표정", "윙크하는 표정". Clean studio lighting, consistent character across all views, 16:9, no logos.

### 최국토 (첨부 : _참고_법무부4인/최법무.jpg)
Using the attached character sheet as the exact reference, keep the same face, bob haircut, round glasses, body proportions and cute 3D chibi Pixar-like render style. Create a new full character reference sheet on a soft light-blue gradient background. Big bold navy Korean title at top left: "최국토", small subtitle: "40세 · 국토교통부 팀장". Character: 40-year-old female team leader, crisp white shirt, black slacks, black shoes, round glasses, sky-blue ID lanyard with tiny text "국토교통부", holding a tablet showing a simple blueprint drawing. Layout: large full-body pose on the left (arms crossed, confident); top row of six small poses with Korean labels "정면", "측면", "후면", "인사 포즈", "서류 들기 포즈", "메모하는 포즈"; bottom row of six face close-ups with Korean labels "행복한 표정", "진지한 표정", "놀란 표정", "걱정한 표정", "결의에 찬 표정", "안경 고쳐 쓰는 표정". Clean studio lighting, consistent character across all views, 16:9, no logos.
