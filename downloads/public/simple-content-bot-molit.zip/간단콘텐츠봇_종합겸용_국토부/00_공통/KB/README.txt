국토부 강의 실습 소재(겨울철 블랙아이스 캠페인).
- molit_01_factsheet.md : 사실 자료 (소스로 사용)
- molit_02~04 : 보고서 작성 규칙 · PDF 디자인 · HTML 모션 규칙 (보고서봇·AI PPT_html봇 참고)
※ 교육용 가상 자료
